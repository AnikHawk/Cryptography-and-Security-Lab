print 'Anik' + "\x00"*6 + 'A+'
